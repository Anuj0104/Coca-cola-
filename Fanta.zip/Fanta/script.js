gsap.from(".txt1",{
  x:1000,  
  opacity:0,
  duration:4,
  stagger:0.5,
})
gsap.from(".txt2,h3",{
    y:-100,
    opacity:0,
    duration:2,
    stagger:0.6,
  })
  gsap.from(".txt3",{
    x:-1000,  
    opacity:0,
    duration:4,
    stagger:0.5,
  })
  gsap.from(".txt4",{
    x:-2000,  
    opacity:0,
    duration:4,
    stagger:0.5,
  })
  gsap.from(".leaf1 ,.leaf2, .leaf3, .leaf4",{
    y:-2000,  
    opacity:1,
    duration:4,
    stagger:0.5,
  })
  gsap.from(".fanta, .orangeup, .orangedown",{
    // y:-2000,  
    opacity:0,
    duration:7,
    stagger:0.5,
  })


  var tl1=gsap.timeline();
  tl1.to(".fanta",{
    x:-400,
    y:850,
    scale:1.1,
    scrollTrigger:{
      trigger:".page2",
      scroller:"body",
      scrub:true,
      // markers:true,
      start:"0% 90%",
      end:"50% 50%",
    }
  },'anuj')
var tl=gsap.timeline();
  tl.to(".fanta",{
    top:"105%",
    left:"56%",
    scale:1.1,
    scrollTrigger:{
      trigger:".page3",
      scroller:"body",
      scrub:true,
      // markers:true,
      start:"30% 100%",
      end:"50% 50%",
    }
  },'page3')

  tl.from(".sprite",{

    rotate:-90,
    scrollTrigger:{
      trigger:".page3",
      scroller:"body",
      scrub:true,
      // markers:true,
      start:"0% 90%",
      end:"50% 50%",
    }
  },'page3')

  tl.from(".coca",{

    rotate:90,
    scrollTrigger:{
      trigger:".page3",
      scroller:"body",
      scrub:true,
      // markers:true,
      start:"0% 90%",
      end:"50% 50%",
    }
  },'page3')

  tl1.to(".orangeup",{
    x:-270,
    y:800,
    scale:1.1,
    scrollTrigger:{
      trigger:".page2",
      scroller:"body",
      scrub:true,
      // markers:true,
      start:"0% 90%",
      end:"50% 50%",
    }
  },'anuj')

  tl.to(".orangeup",{
    top:700,
    left:920,
    scale:1.1,
    scrollTrigger:{
      trigger:".page3",
      scroller:"body",
      scrub:true,
      // markers:true,
      start:"0% 90%",
      end:"50% 50%",
    }
  },'page3')

  tl1.to(".orangedown",{
    top:90,
    left:850,
    scale:1.2,
    scrollTrigger:{
      trigger:".page3",
      scroller:"body",
      scrub:true,
      // markers:true,
      start:"0% 90%",
      end:"50% 50%",
    }
  },'anuj')

  tl1.to(".leaf3",{
    x:250,
    y:300,
    scale:1.2,
    rotate:140,
    scrollTrigger:{
      trigger:".page2",
      scroller:"body",
      scrub:true,
      // markers:true,
      start:"0% 90%",
      end:"50% 50%",
    }
  },'anuj')